import express from 'express';
import { addBook, getAllBooks, getBookById, updateBookById, deleteBookById } from './books.js';

const app = express();
const port = 9000;

app.use(express.json()); // built-in middleware

app.post('/books', (req, res) => {
    const result = addBook(req.body);

    if (result.error) {
        return res.status(400).json({
            status: 'fail',
            message: result.error
        });
    }

    return res.status(201).json({
        status: 'success',
        message: 'Buku berhasil ditambahkan',
        data: {
            bookId: result.id
        }
    });
});

app.get('/books', (req, res) => {
    const books = getAllBooks();

    return res.status(200).json({
        status: 'success',
        data: {
            books
        }
    });
});

app.get('/books/:bookId', (req, res) => {
    const book = getBookById(req.params.bookId);

    if (!book) {
        return res.status(404).json({
            status: 'fail',
            message: 'Buku tidak ditemukan'
        });
    }

    return res.status(200).json({
        status: 'success',
        data: {
            book
        }
    });
});

app.put('/books/:bookId', (req, res) => {
    const result = updateBookById(req.params.bookId, req.body);

    if (result.error) {
        if (result.error.includes('Id tidak ditemukan')) {
            return res.status(404).json({
                status: 'fail',
                message: result.error
            });
        }

        return res.status(400).json({
            status: 'fail',
            message: result.error
        });
    }

    return res.status(200).json({
        status: 'success',
        message: 'Buku berhasil diperbarui'
    });
});

app.delete('/books/:bookId', (req, res) => {
    const result = deleteBookById(req.params.bookId);

    if (result.error) {
        return res.status(404).json({
            status: 'fail',
            message: result.error
        });
    }

    return res.status(200).json({
        status: 'success',
        message: 'Buku berhasil dihapus'
    });
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
